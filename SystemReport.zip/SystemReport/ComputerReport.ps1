﻿#Created by Moises Rodriguez Perez/Moirodri-1991@outlook.com
#Date Created 5/17/2020

#CSS Code 
$header = @"
<style>

    h1 {

        font-family: Arial, Helvetica, sans-serif;
        color: #000000;
        font-size: 28px;

    }

    
    h2 {

        font-family: Arial, Helvetica, sans-serif;
        color: #000099;
        font-size: 16px;

    }

    
    
   table {
		font-size: 12px;
		border: 0px; 
		font-family: Arial, Helvetica, sans-serif;
	} 
	
    td {
		padding: 4px;
		margin: 0px;
		border: 0;
	}
	
    th {
        background: #395870;
        background: linear-gradient(#49708f, #293f50);
        color: #fff;
        font-size: 11px;
        text-transform: uppercase;
        padding: 10px 15px;
        vertical-align: middle;
	}

    tbody tr:nth-child(even) {
        background: #f0f0f2;
    }

        #CreationDate {

        font-family: Arial, Helvetica, sans-serif;
        color: #ff3300;
        font-size: 12px;

    }
    
</style>

"@
#script
$WindowsInstallDateFromRegistry = @{
Name = 'OS date installed'
Expression ={$_.WindowsInstallDateFromRegistry}}
$CsPartOfDomain = @{
Name = 'PartOfDomain'
Expression = {$_.CsPartOfDomain}}
$CsDomain = @{
Name = 'Domain Name'
Expression = {$_.CsDomain}}
write-Host "Please wait generating Computer Information Report" -ForegroundColor green 
$Info = "<h1>Computer Information Report</h1>"
$ComputerName = "<h2>Computer name: $env:computername</h2>"
$OSinfo = Get-ComputerInfo -Property *  | Select-Object WindowsProductName,WindowsVersion,$WindowsInstallDateFromRegistry,$CsDomain,$CsPartOfDomain | ConvertTo-Html  -Fragment -PreContent "<h2>Operating System Information</h2>"
$Domain = Get-WmiObject -Class Win32_ComputerSystem -Property * | Select-Object Domain
$BiosInfo = Get-CimInstance -ClassName Win32_BIOS | ConvertTo-Html -Property SMBIOSBIOSVersion,Manufacturer,Name,SerialNumber -Fragment -PreContent "<h2>BIOS Information</h2>"
$BitLocker = Get-BitLockerVolume -MountPoint C: |select MountPoint,VolumeStatus,ProtectionStatus|ConvertTo-Html  -Fragment -PreContent "<h2>Bitlocker Status </h2>"
$DiscInfo = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" -Property * |Select-Object  DeviceID, @{'Name'='Size (GB)'; 'Expression'={[math]::truncate($_.size / 1GB)}}, @{'Name'='Freespace (GB)'; 'Expression'={[math]::truncate($_.freespace / 1GB)}}|ConvertTo-Html -Fragment -PreContent "<h2>Disk Information</h2>"
$SoftInfo = Get-CimInstance -ClassName win32_Product -Property * | Select-Object Name,Version,InstallDate,Vendor |ConvertTo-Html  -Fragment -PreContent "<h2>Software Information</h2>"
$driinfo = Get-CimInstance -className Win32_PnPSignedDriver -Property * | Select-Object devicename, driverversion,DriverProviderName,Manufacturer |ConvertTo-Html  -Fragment -PreContent "<h2>Drivers Information</h2>"
#Reporting 
$Report = ConvertTo-HTML -Body "$head $Info $ComputerName $OSinfo  $BiosInfo $BitLocker $DiscInfo  $SoftInfo $driinfo"  -Title "Computer Information Report" -Head $header -PostContent "<p>Creates by Moises Rodriguez Date created: $(Get-Date)</p>" 
$Report | Out-File C:\SystemReport\SystemReport.html
Write-host "Report was create few second will be open"  -ForegroundColor green 
Invoke-Item  c:\SystemReport\SystemReport.html
